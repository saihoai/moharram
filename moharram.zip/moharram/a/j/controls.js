/* global colorScheme, Color */
/**
 * Add a listener to the Color Scheme control to update other color controls to new values/defaults.
 * Also trigger an update of the Color Scheme CSS when a color is changed.
 */

( function( api ) {
	var 
		colorSettings = [ 'cbase' ],
		bgSettings = [ 'background_image' ],
		refershSettings = [ 
			'wood_col', 'wood_mode',

			'woor_mode', 'woor_row', 'woor_col',
			
			'woos_thumbnails_pos', 'woos_thumbnails_items',

			'loader_style',

			'h_tmpl',
		],
		colorTemplate = wp.template( 'moharram-color' )
	;

	// Generate the CSS for the current Color Scheme.
	function updateCSS() {
		var data = {};

		// Merge in color scheme overrides.
		_.each( colorSettings, function( setting ) {
			data[ setting ] = api( setting )();
		} );
		data.cbase_a = Color( data.cbase ).toCSS( 'rgba', 0.8 )

		api.previewer.send( 'update-color-css', colorTemplate( data ) );
	}

	// Update the CSS whenever a color setting is changed.
	_.each( colorSettings, function( setting ) {
		api( setting, function( setting ) {
			setting.bind( updateCSS );
		} );
	} );

	// Update the CSS whenever a bg setting is changed.
	_.each( bgSettings, function( setting ) {
		api( setting, function( setting ) {
			setting.bind( function() {
				var d = {
						v: api( bgSettings[0] )(),
						css: wp.template( 'moharram-bg' )()
					}
				;
				api.previewer.send( 'update-bg-css', d );	
			} );
		} );
	} );

	// Update the CSS whenever a bg setting is changed.
	_.each( refershSettings, function( setting ) {
		api( setting, function( setting ) {
			setting.bind( function() {
				api.previewer.refresh();
			} );
		} );
	} );


} )( wp.customize );
