/**
 * Live-update changed settings in real time in the Customizer preview.
 */

( function( $ ) {
	var 
		style_color = $( '#moharramm-color' ),
		style_bg = $( '#moharramm-bg' ),
		api = wp.customize;

	if ( !style_color.length ) {
		style_color = $( 'head' ).append( '<style type="text/css" id="moharramm-color" />' ).find( '#moharramm-color' );
	}

	if ( !style_bg.length ) {
		style_bg = $( 'head' ).append( '<style type="text/css" id="moharramm-bg" />' ).find( '#moharramm-bg' );
	}

	// Site title.
	api( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );

	// Site tagline.
	api( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$( '.site-description' ).text( to );
		} );
	} );

	// Color Scheme CSS.
	api.bind( 'preview-ready', function() {
		api.preview.bind( 'update-color-css', function( css ) {
			style_color.html( css );
		} );
	} );

	// Background CSS.
	api.bind( 'preview-ready', function() {
		api.preview.bind( 'update-bg-css', function( d ) {
			$( '#hero' )[ d.v ? 'addClass' : 'removeClass' ]( 'container' );
			style_bg.html( d.css );
		} );
	} );
} )( jQuery );
