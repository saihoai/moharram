jQuery( function( $ ) {
	var e = $( '#fx-row' ),
		p = e.parent()
	;

    e.attr( 'data-color', e.attr( 'data-color' ).replace( 'a)', '' ) );
	
	if( p.find( '.upb_row_bg' ).length  )
    {
    	e.insertAfter( '.upb_row_bg' );
    }
    else
    {
    	p.prepend( e );
    }
} );