
<br>
<?php global $post; ?>
<div class="post-author">
	<?php
	/**
	 * Filter the moharram author bio avatar size.
	 *
	 * @since moharram 1.0
	 *
	 * @param int $size The avatar height and width size in pixels.
	 */
	$author_bio_avatar_size = apply_filters( 'moharram_author_bio_avatar_size', 90 );

	echo get_avatar( get_the_author_meta( 'user_email', $post->post_author ), $author_bio_avatar_size, '', '', array( 'class' => 'img-responsive img-circle' ) );
	?>
    <p>
        <?php esc_html_e( 'By', 'struct' ); ?> <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><i><?php the_author_meta( 'display_name', $post->post_author ); ?></i></a>
        <br> <?php esc_html_e( 'On', 'struct' ); ?> <i><?php echo get_the_date();?> </i>
    </p>
</div>