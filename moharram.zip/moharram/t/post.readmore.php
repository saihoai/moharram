<div class="row">
	<div class="col-md-3">
		<a class="more-link" href="<?php echo esc_url( get_permalink() ); ?>"><?php esc_html_e( 'Continue Readding', 'moharram' ); ?></a>
	</div>
	<?php $url = get_permalink(); ?>
	<?php $title = get_the_title(); ?>
	<?php $excerpt = get_the_excerpt(); ?>
	<?php $media = ""; ?>
	<?php if( has_post_thumbnail() ) : ?>
		<?php list( $media ) = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), "full" ); ?>
	<?php endif ?>
	<?php $links = array(
		'<a href="'.esc_url('https://www.facebook.com/sharer/sharer.php?u='.$url).'" class="btn btn-primary pull-right" target="_blank"><i class="fa fa-facebook"></i></a>',
		'<a href="'.esc_url('https://twitter.com/home?status='.$url).'" class="btn btn-primary pull-right" target="_blank"><i class="fa fa-twitter"></i></a>',
		'<a href="'.esc_url('https://plus.google.com/share?url='.$url).'" class="btn btn-primary pull-right" target="_blank"><i class="fa fa-google-plus"></i></a>',
		'<a href="'.esc_url('https://www.linkedin.com/shareArticle?mini=true&url='.$url.'&title='.$title.'&summary='.$excerpt.'&source=').'" class="btn btn-primary pull-right" target="_blank"><i class="fa fa-linkedin"></i></a>',
		'<a href="'.esc_url('https://pinterest.com/pin/create/button/?url='.$url.'&media='.$media.'&description='.$excerpt).'" class="btn btn-primary pull-right" target="_blank"><i class="fa fa-pinterest"></i></a>',
	); ?>
	<div class="col-md-9">
		<?php foreach( $links as $item ): ?>
			<?php echo $item; ?>
    	<?php endforeach ?>
	</div>
</div>