<?php
/**
 * Single Product Share
 *
 * Sharing plugins can hook into here or you can add your own code directly.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/share.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<?php $url = get_permalink(); ?>
<?php $title = get_the_title(); ?>
<?php $excerpt = get_the_excerpt(); ?>
<?php $media = ""; ?>
<?php if( has_post_thumbnail() ) : ?>
	<?php list( $media ) = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), "full" ); ?>
<?php endif ?>
<?php $links = array(
	'<a href="'.esc_url('https://www.facebook.com/sharer/sharer.php?u='.$url).'" class="btn btn-primary btn-xs" target="_blank"><i class="fa fa-facebook"></i></a>',
	'<a href="'.esc_url('https://twitter.com/home?status='.$url).'" class="btn btn-primary btn-xs" target="_blank"><i class="fa fa-twitter"></i></a>',
	'<a href="'.esc_url('https://plus.google.com/share?url='.$url).'" class="btn btn-primary btn-xs" target="_blank"><i class="fa fa-google-plus"></i></a>',
	'<a href="'.esc_url('https://www.linkedin.com/shareArticle?mini=true&url='.$url.'&title='.$title.'&summary='.$excerpt.'&source=').'" class="btn btn-primary btn-xs" target="_blank"><i class="fa fa-linkedin"></i></a>',
	'<a href="'.esc_url('https://pinterest.com/pin/create/button/?url='.$url.'&media='.$media.'&description='.$excerpt).'" class="btn btn-primary btn-xs" target="_blank"><i class="fa fa-pinterest"></i></a>',
); ?>
<div class="product-share">
	<?php foreach( $links as $item ): ?>
		<?php echo $item; ?>
	<?php endforeach ?>
</div>