<?php

/**
 * Core class used to implement the Button widget.
 *
 * @since 3.0.0
 *
 * @see WP_Widget
 */
class Moharram_Button_Widget extends WP_Widget {

	/**
	 * Sets up a new Button widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'description' => __( 'Add a button to your sidebar.' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'button', __('Button'), $widget_ops );
	}

	/**
	 * Outputs the content for the current Button widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Custom Menu widget instance.
	 */
	public function widget( $args, $instance ) {
		$link_url = isset( $instance['link_url'] ) ? $instance['link_url'] : '';
		$link_text = isset( $instance['link_text'] ) ? $instance['link_text'] : '';
		$link_class = isset( $instance['link_class'] ) ? $instance['link_class'] : '';

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		echo $args['before_widget'];

		if ( !empty($instance['title']) )
			echo $args['before_title'] . $instance['title'] . $args['after_title'];

		echo '<a class="'.$link_class.'" href="'.$link_url.'">'.$link_text.'</a>';

		echo $args['after_widget'];
	}

	/**
	 * Handles updating settings for the current Custom Menu widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['link_url'] ) ) {
			$instance['link_url'] = $new_instance['link_url'];
		}
		if ( ! empty( $new_instance['link_text'] ) ) {
			$instance['link_text'] = $new_instance['link_text'];
		}
		if ( ! empty( $new_instance['link_class'] ) ) {
			$instance['link_class'] = $new_instance['link_class'];
		}
		return $instance;
	}

	/**
	 * Outputs the settings form for the Custom Menu widget.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 * @global WP_Customize_Manager $wp_customize
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : '';
		$link_url = isset( $instance['link_url'] ) ? $instance['link_url'] : '';
		$link_text = isset( $instance['link_text'] ) ? $instance['link_text'] : '';
		$link_class = isset( $instance['link_class'] ) ? $instance['link_class'] : '';

		?>
		<div class="buton-widget-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'moharram' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $title ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'link_url' ); ?>"><?php _e( 'Link url:', 'moharram' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'link_url' ); ?>" value="<?php echo esc_attr( $link_url ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'link_text' ); ?>"><?php _e( 'Link text:', 'moharram' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'link_text' ); ?>" name="<?php echo $this->get_field_name( 'link_text' ); ?>" value="<?php echo esc_attr( $link_text ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'link_class' ); ?>"><?php _e( 'Link class:', 'moharram' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'link_class' ); ?>" name="<?php echo $this->get_field_name( 'link_class' ); ?>" value="<?php echo esc_attr( $link_class ); ?>"/>
			</p>
		</div>
		<?php
	}
}

function moharram_button_load_widget() {
	register_widget( 'Moharram_Button_Widget' );
}
add_action( 'widgets_init', 'moharram_button_load_widget' );

