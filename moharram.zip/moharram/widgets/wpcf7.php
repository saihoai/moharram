<?php

/**
 * Core class used to implement the Contact Form 7 Widget widget.
 *
 * @since 3.0.0
 *
 * @see WP_Widget
 */
class Moharram_WPCF7_Widget extends WP_Widget {

	/**
	 * Sets up a new Contact Form 7 Widget widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'description' => __( 'Add a Contact Form 7 Widget to your sidebar.' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'wpcf7_widget', __('Contact Form 7 Widget'), $widget_ops );
	}

	/**
	 * Outputs the content for the current Contact Form 7 Widget widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Custom Menu widget instance.
	 */
	public function widget( $args, $instance ) {
		$desc = isset( $instance['desc'] ) ? $instance['desc'] : '';
		$frm_id = isset( $instance['frm_id'] ) ? $instance['frm_id'] : '';

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		echo $args['before_widget'];

			if ( !empty($instance['title']) )
			{
				echo $args['before_title'];
					echo $instance['title'];
					if( !empty( $desc ) )
					{
						echo "<span>{$desc}</span>";
					}
				echo $args['after_title'];
			}

			echo do_shortcode( "[contact-form-7 id='{$frm_id}']" );

		echo $args['after_widget'];
	}

	/**
	 * Handles updating settings for the current Custom Menu widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['desc'] ) ) {
			$instance['desc'] = $new_instance['desc'];
		}
		if ( ! empty( $new_instance['frm_id'] ) ) {
			$instance['frm_id'] = $new_instance['frm_id'];
		}
		return $instance;
	}

	/**
	 * Outputs the settings form for the Custom Menu widget.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 * @global WP_Customize_Manager $wp_customize
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : '';
		$desc = isset( $instance['desc'] ) ? $instance['desc'] : '';
		$frm_id = isset( $instance['frm_id'] ) ? $instance['frm_id'] : '';
		$args = array(
			'posts_per_page'   => -1,
			'post_type'        => 'wpcf7_contact_form',
		);
		$rs = get_posts( $args );

		?>
		<?php if( count( $rs ) > 0 ) : ?>
		<div class="buton-widget-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'moharram' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $title ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'desc' ); ?>"><?php _e( 'Description:', 'moharram' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'desc' ); ?>" name="<?php echo $this->get_field_name( 'desc' ); ?>" value="<?php echo esc_attr( $desc ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'frm_id' ); ?>"><?php _e( 'Form:', 'moharram' ) ?></label>
				<select class="widefat" id="<?php echo $this->get_field_id( 'frm_id' ); ?>" name="<?php echo $this->get_field_name( 'frm_id' ); ?>">
				<?php foreach( $rs as $item ) :?>
					<option value="<?php echo esc_attr( $item->ID ); ?>" <?php selected( $frm_id, $item->ID ); ?>><?php echo esc_html( $item->post_title ); ?></option>
				<?php endforeach ?>
				</select>
			</p>
		</div>
		<?php endif ?>
		<?php
	}
}

if( !function_exists( 'moharram_wpcf7_load_widget' ) )
{
	function moharram_wpcf7_load_widget() 
	{
		register_widget( 'Moharram_WPCF7_Widget' );
	}
}
add_action( 'widgets_init', 'moharram_wpcf7_load_widget' );

